const signalingServerUrl = 'ws://localhost:8080';
let localStream;
let peerConnection;

// Create WebSocket connection with signaling server
const ws = new WebSocket(signalingServerUrl);

// Handler for incoming messages from the signaling server
ws.onmessage = async event => {
    const message = JSON.parse(event.data);
    switch (message.type) {
        case 'offer':
            // Set remote description and create answer
            await peerConnection.setRemoteDescription(new RTCSessionDescription(message.offer));
            const answer = await peerConnection.createAnswer();
            await peerConnection.setLocalDescription(answer);

            // Send answer to signaling server
            ws.send(JSON.stringify({ type: 'answer', answer: answer }));
            break;
        case 'answer':
            // Set remote description
            await peerConnection.setRemoteDescription(new RTCSessionDescription(message.answer));
            break;
        case 'candidate':
            // Add ICE candidate to peer connection
            await peerConnection.addIceCandidate(new RTCIceCandidate(message.candidate));
            break;
        default:
            console.error('Invalid message type:', message.type);
            break;
    }
};

// Get local media stream and display it in local video element
navigator.mediaDevices.getUserMedia({ video: true, audio: true })
    .then(stream => {
        localStream = stream;
        const localVideo = document.getElementById('local-video');
        localVideo.srcObject = stream;
        localVideo.muted = true;
        localVideo.play();
        document.getElementById('call-btn').disabled = false;
    })
    .catch(error => {
        console.error('Error getting local media stream:', error);
    });

// Handler for call button click
document.getElementById('call-btn').onclick = async () => {
    // Create new peer connection
    peerConnection = new RTCPeerConnection();

    // Add local media stream to peer connection
    localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream);
    });

    // Handler for ICE candidate events
    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            // Send ICE candidate to signaling server
            ws.send(JSON.stringify({ type: 'candidate', candidate: event.candidate }));
        }
    };

    // Handler for remote stream events
    peerConnection.ontrack = event => {
       
        const remoteVideo = document.getElementById('remote-video');
        remoteVideo.srcObject = event.streams[0];
        remoteVideo.play();
    };
    
    // Create offer and set local description
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    
    // Send offer to signaling server
    ws.send(JSON.stringify({ type: 'offer', offer: offer }));
    
    // Enable hangup button
    document.getElementById('hangup-btn').disabled = false;
};

// Handler for hangup button click
document.getElementById('hangup-btn').onclick = () => {
// Close peer connection and stop local media stream
peerConnection.close();
localStream.getTracks().forEach(track => {
track.stop();
});
localStream = null;
// Reset video elements
const localVideo = document.getElementById('local-video');
localVideo.srcObject = null;
const remoteVideo = document.getElementById('remote-video');
remoteVideo.srcObject = null;

// Disable call and hangup buttons
document.getElementById('call-btn').disabled = true;
document.getElementById('hangup-btn').disabled = true;
};